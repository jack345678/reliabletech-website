export default function Industries() {
  const industries = [
    "Healthcare",
    "Legal",
    "Accounting",
    "Construction",
    "Retail",
    "Government Contractors",
  ];

  return (
    <section className="bg-slate-50 py-20">
      <div className="mx-auto max-w-7xl px-6">
        <h2 className="mb-10 text-center text-4xl font-bold">
          Industries We Serve
        </h2>

        <div className="grid gap-6 md:grid-cols-3">
          {industries.map((industry) => (
            <div
              key={industry}
              className="rounded-xl border bg-white p-6 text-center shadow-sm"
            >
              {industry}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}