"use client";

import Link from "next/link";
import Image from "next/image";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 bg-white shadow">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6 max-w-7xl">

        <Link href="/" className="flex items-center gap-3">
          <Image
            src="/logo.png"
            alt="ReliableTech IT Solutions LLC"
            width={56}
            height={56}
            priority
          />

          <div>
            <h1 className="text-xl font-bold text-slate-900">
              ReliableTech
            </h1>

            <p className="text-xs text-slate-500">
              IT Solutions LLC
            </p>
          </div>
        </Link>

        <nav className="hidden md:flex gap-8">
          <Link href="/" className="transition hover:text-blue-700">
            Home
          </Link>

          <Link href="/about" className="transition hover:text-blue-700">
            About
          </Link>

          <Link href="/services" className="transition hover:text-blue-700">
            Services
          </Link>

          <Link href="/faq" className="transition hover:text-blue-700">
            FAQ
          </Link>

          <Link href="/contact" className="transition hover:text-blue-700">
            Contact
          </Link>
        </nav>

        <Link
          href="/contact"
          className="rounded-lg bg-blue-700 px-5 py-3 font-semibold text-white transition hover:bg-blue-800"
        >
          Free Consultation
        </Link>

      </div>
    </header>
  );
}