export default function Technologies() {
  const technologies = [
    "Microsoft 365",
    "Azure",
    "Windows Server",
    "Microsoft Intune",
    "VMware",
    "Cisco",
    "PowerShell",
    "AWS",
  ];

  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-6">
        <h2 className="mb-10 text-center text-4xl font-bold">
          Technologies We Support
        </h2>

        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {technologies.map((tech) => (
            <div
              key={tech}
              className="rounded-xl border bg-white p-5 text-center shadow-sm"
            >
              {tech}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}